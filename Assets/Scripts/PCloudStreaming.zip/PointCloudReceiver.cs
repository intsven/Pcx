﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics;

namespace RosSharp.RosBridgeClient
{
    public class PointCloudReceiver : MessageReceiver
    {
        public PointCloudManager pManager;
        public Transform pContainer;

        private bool isMessageReceived;
        private PCloud pCloud;
        private SensorPointCloud2 msg;

        private GameObject go = null;

        public override Type MessageType { get { return (typeof(SensorPointCloud2)); } }

        private void Awake()
        {
            MessageReception += ReceiveMessage;
        }

        private void ReceiveMessage(object sender, MessageEventArgs e)
        {
            UnityEngine.Debug.Log("ReceiveMessage: Start -> " + System.DateTime.Now.ToLongTimeString());

            Stopwatch sw = new Stopwatch();
            sw.Start();

            //pCloud = new PCloud((SensorPointCloud2)e.Message);
            msg = (SensorPointCloud2)e.Message;
            isMessageReceived = true;

            sw.Stop();
            UnityEngine.Debug.Log("ReceiveMessage Elapsed: " + sw.Elapsed.TotalMilliseconds);

            UnityEngine.Debug.Log("ReceiveMessage: Done  -> " + System.DateTime.Now.ToLongTimeString());
        }

        // Update is called once per frame
        void Update()
        {
            if (isMessageReceived)
            {
                UnityEngine.Debug.Log("Update: Start -> " + System.DateTime.Now.ToLongTimeString());

                Stopwatch sw = new Stopwatch();
                sw.Start();

                ProcessMessage();

                sw.Stop();
                UnityEngine.Debug.Log("Update Elapsed: " + sw.Elapsed.TotalMilliseconds);
                UnityEngine.Debug.Log("Update: Done -> " + System.DateTime.Now.ToLongTimeString());
            }
        }

        private void ProcessMessage()
        {
            if (go != null)
            {
                GameObject.Destroy(go);
            }

            go = new GameObject();
            go.transform.SetParent(pContainer);

            go.transform.localPosition = new Vector3(0, 0, 0);
            go.transform.localRotation = Quaternion.identity;
            go.transform.localScale = new Vector3(1, 1, 1);

            //pManager.LoadPointCloud(go, pCloud);
            pManager.LoadPointCloud(go, msg);
            isMessageReceived = false;
        }
    }
}