﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Pcx;
using RosSharp.RosBridgeClient;
using System;

public class PointCloudManager : MonoBehaviour
{
    public void LoadPointCloud(GameObject go, SensorPointCloud2 pCloud)
    {
        // ComputeBuffer container
        // Create a prefab with PointCloudRenderer.

        var data = ImportPointCloudData(pCloud);
        var renderer = go.AddComponent<PointCloudRenderer>();

        renderer.pointShader = Shader.Find("Point Cloud/Point");
        renderer.diskShader = Shader.Find("Point Cloud/Disk");

        renderer.pointSize = 0.015f;
        renderer.sourceData = data;
    }

    public void LoadPointCloud(GameObject go, PCloud pCloud)
    {
        // ComputeBuffer container
        // Create a prefab with PointCloudRenderer.

        var data = ImportPointCloudData(pCloud);
        var renderer = go.AddComponent<PointCloudRenderer>();

        renderer.pointShader = Shader.Find("Point Cloud/Point");
        renderer.diskShader = Shader.Find("Point Cloud/Disk");

        renderer.pointSize = 0.0f;
        renderer.sourceData = data;
    }

    private PointCloudData ImportPointCloudData(SensorPointCloud2 pCloud)
    {
        try
        {
            var data = ScriptableObject.CreateInstance<PointCloudData>();
            data.Initialize(pCloud);
            data.name = "RosCloud";
            return data;
        }
        catch (Exception e)
        {
            Debug.LogError("Failed importing data " + e.Message);
            return null;
        }
    }

    private PointCloudData ImportPointCloudData(PCloud pCloud)
    {
        try
        {
            var data = ScriptableObject.CreateInstance<PointCloudData>();
            data.Initialize(pCloud.vertices, pCloud.colors);
            data.name = "RosCloud";
            return data;
        }
        catch (Exception e)
        {
            Debug.LogError("Failed importing data " + e.Message);
            return null;
        }
    }
}
